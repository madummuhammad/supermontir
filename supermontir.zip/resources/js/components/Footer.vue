<template>
        <footer class="bg-gray-300 p-4 flex justify-center md:justify-start py-4">
          <img src="@assets/images/logo.png" alt="" />
        </footer>
</template>
